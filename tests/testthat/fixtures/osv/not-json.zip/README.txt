Not an OSV record.
